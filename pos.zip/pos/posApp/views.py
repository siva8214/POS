from pickle import FALSE
from venv import logger
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse, JsonResponse
from flask import jsonify
from pos import settings
from posApp.models import Category, Products, Sales, salesItems, ReturnedItems
from django.db.models import Count, Sum, F
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import never_cache
from django.shortcuts import redirect
import json, sys
from datetime import date, datetime
from django.db.models import Q
import barcode
from barcode.writer import ImageWriter
from io import BytesIO
from django.core.files.base import ContentFile
import barcode
from barcode.writer import ImageWriter
from django.http import HttpResponseServerError
from io import BytesIO
import logging
from PIL import Image
from .models import CartItem, Customer, Sales, salesItems
from barcode import Code128
from django.utils import timezone
from decimal import Decimal, ROUND_HALF_UP
from django.core.mail import send_mail
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import time
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse, HttpResponseRedirect
from django.urls import reverse


# Login
def login_user(request):
    logout(request)
    resp = {"status":'failed','msg':''}
    username = ''
    password = ''
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                request.session['logged_in'] = True
                resp['status']='success'
            else:
                resp['msg'] = "Incorrect username or password"
        else:
            resp['msg'] = "Incorrect username or password"
    return HttpResponse(json.dumps(resp),content_type='application/json')

#Logout
def logoutuser(request):
    logout(request)
    request.session.clear()
    return redirect('/')


@login_required
@never_cache
def home(request):
    user_groups = request.user.groups.all()
    # print(user_groups)
    u=request.user
    now = datetime.now()
    current_year = now.strftime("%Y")
    current_month = now.strftime("%m")
    current_day = now.strftime("%d")
    categories = len(Category.objects.all())
    products = len(Products.objects.all())
    transaction = len(Sales.objects.filter(
        date_added__year=current_year,
        date_added__month = current_month,
        date_added__day = current_day
    ))
    today_sales = Sales.objects.filter(
        date_added__year=current_year,
        date_added__month = current_month,
        date_added__day = current_day
    ).all()
    total_sales = sum(today_sales.values_list('grand_total',flat=True))
    context = {
        'page_title':'Home',
        'categories' : categories,
        'user_groups': user_groups,
        'u':u,
        'products' : products,
        'transaction' : transaction,
        'total_sales' : total_sales,
    }
    return render(request, 'posApp/home.html',context)


def about(request):
    context = {
        'page_title':'About',
    }
    return render(request, 'posApp/about.html',context)


@login_required
@never_cache
def category(request):
    user_groups = request.user.groups.all()
    u=request.user
    category_list = Category.objects.all()
    context = {
        'page_title':'Category List',
        'category':category_list,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/category.html',context)

@login_required
@never_cache
def manage_category(request):
    user_groups = request.user.groups.all()
    u=request.user
    category = {}
    if request.method == 'GET':
        data =  request.GET
        id = ''
        if 'id' in data:
            id= data['id']
        if id.isnumeric() and int(id) > 0:
            category = Category.objects.filter(id=id).first()
    
    context = {
        'category' : category,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/manage_category.html',context)

@login_required
@never_cache
def save_category(request):
    data =  request.POST
    resp = {'status':'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0 :
            save_category = Category.objects.filter(id = data['id']).update(name=data['name'] )
        else:
            save_category = Category(name=data['name'] )
            save_category.save()
        resp['status'] = 'success'
        messages.success(request, 'Category Successfully saved.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
@never_cache
def delete_category(request):
    data =  request.POST
    resp = {'status':''}
    try:
        Category.objects.filter(id = data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Category Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
@never_cache
def products(request):
    user_groups = request.user.groups.all()
    u=request.user
    search_query = request.GET.get('q', '')
    expirydate = request.GET.get('expirydate', '')

    filters = Q()
    
    if search_query:
        filters &= (Q(name__icontains=search_query) | 
                    Q(code__icontains=search_query) | 
                    Q(category_id__name__icontains=search_query))
    
    if expirydate:
        try:
            expirydate = datetime.strptime(expirydate, '%Y-%m-%d').date()
            filters &= Q(expirydate__lte=expirydate)
        except ValueError:
            
            pass

    product_list = Products.objects.filter(filters)

    context = {
        'page_title': 'Product List',
        'products': product_list,
        'search_query': search_query,
        'expiry_date': expirydate,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/products.html', context)

@login_required
@never_cache
def manage_products(request):
    user_groups = request.user.groups.all()
    u=request.user
    product = {}
    categories = Category.objects.all()
    if request.method == 'GET':
        data =  request.GET
        id = ''
        if 'id' in data:
            id= data['id']
        if id.isnumeric() and int(id) > 0:
            product = Products.objects.filter(id=id).first()
    
    context = {
        'product' : product,
        'categories' : categories,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/manage_product.html',context)

def test(request):
    categories = Category.objects.all()
    context = {
        'categories' : categories
    }
    return render(request, 'posApp/test.html',context)

@login_required
@never_cache
def save_product(request):
    data = request.POST
    resp = {'status': 'failed'}

    
    id = data.get('id', '')

    try:
        category = Category.objects.filter(id=data['category_id']).first()
        
        
        expirydate = data.get('expirydate')
        if expirydate:
            expirydate = datetime.strptime(expirydate, '%Y-%m-%d').date()

        if id.isnumeric() and int(id) > 0:
            product = Products.objects.get(id=id)
            product.code = data['code']
            product.category_id = category
            product.name = data['name']
            product.qty = data['qty']
            product.price = float(data['price'])
            product.mrp = float(data['mrp'])
            product.expirydate = expirydate
            product.stock = int(data.get('stock', 0))
        else:
            product = Products.objects.create(
                code=data['code'],
                category_id=category,
                name=data['name'],
                qty=data['qty'],
                price=float(data['price']),
                mrp=float(data['mrp']),
                expirydate=expirydate,
                stock=int(data.get('stock', 0))
            )

        product.save()

      
        buffer = BytesIO()
        code128 = Code128(product.code, writer=ImageWriter())
        code128.write(buffer)
        barcode_filename = f"{product.code}_{product.id}.png" 

        
        with open(barcode_filename, 'wb') as f:
            f.write(buffer.getvalue())

       
        product.barcode = barcode_filename
        product.save()

        resp['status'] = 'success'
        messages.success(request, 'Product Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
        resp['msg'] = str(e)

    return JsonResponse(resp)


@login_required
@never_cache
def delete_product(request):
    data =  request.POST
    resp = {'status':''}
    try:
        Products.objects.filter(id = data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Product Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")


@login_required
@never_cache
def pos(request):
    user_groups = request.user.groups.all()
    u=request.user
    products = Products.objects.all()
    product_json = []
    for product in products:
        product_json.append({
            'id': product.id,
            'name': product.name,
            'mrp': float(product.mrp),
            'price': float(product.price),
            'code': product.code,
            'expirydate': product.expirydate.isoformat() if product.expirydate else None,
            'stock': float(product.stock)
        })
    context = {
        'page_title': "Point of Sale",
        'products': products,
        'product_json': json.dumps(product_json),
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/pos.html', context)


@login_required
@never_cache
def checkout_modal(request):
    user_groups = request.user.groups.all()
    u=request.user
    grand_total = 0
    if 'grand_total' in request.GET:
        grand_total = request.GET['grand_total']
    context = {
        'grand_total' : grand_total,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/checkout.html',context)

@login_required
@never_cache
def save_pos(request):
    resp = {'status': 'failed', 'msg': ''}
    data = request.POST
    product_ids = [pid for pid in data.getlist('product_id[]') if pid]  
    current_year = datetime.now().year
    pref = f"INV/{current_year}/"

    for product_id in product_ids:
        product = Products.objects.get(id=product_id)
        if product.expirydate and product.expirydate < timezone.now().date():
            resp['msg'] = f"The product '{product.name}' is expired and cannot be billed."
            return JsonResponse(resp)

    i = 1
    while True:
        code = f"{pref}{i:05d}"
        if not Sales.objects.filter(code=code).exists():
            break
        i += 1

    try:
        sgst_percent = float(data.get('sgst', 0))
        cgst_percent = float(data.get('cgst', 0))

        sales = Sales.objects.create(
            code=code,
            sub_total=float(data['sub_total']),
            tax_amount=float(data['total_tax']),
            grand_total=float(data['grand_total']),
            tendered_amount=float(data['tendered_amount']),
            amount_change=float(data['amount_change']),
            customer_name=data.get('customer_name', ''),
            customer_phone=data.get('customer_phone', ''),
            payment_method=data.get('payment_method', ''),
            sgst_percent=sgst_percent,
            cgst_percent=cgst_percent
        )

        sale_id = sales.pk

        customer_name = data.get('customer_name', '')
        customer_phone = data.get('customer_phone', '')
        customer_city = data.get('customer_city', '')
        customer_area = data.get('customer_area', '')

        customer, created = Customer.objects.get_or_create(
            name=customer_name,
            phone_number=customer_phone,
            defaults={'city': customer_city, 'area': customer_area}
        )

        if not created:  
            customer.city = customer_city
            customer.area = customer_area
            customer.save()

        for i, prod in enumerate(product_ids):
            product = Products.objects.get(id=prod)
            qty = float(data.getlist('qty[]')[i])
            price = float(data.getlist('price[]')[i])
            mrp = float(data.getlist('mrp[]')[i])
            total = qty * price

            if product.stock < qty:
                resp['msg'] = f"The product '{product.name}' is out of stock."
                return JsonResponse(resp)
            
            sales_item = salesItems.objects.create(
                sale_id=sales,
                product_id=product,
                qty=qty,
                price=price,
                mrp=mrp,
                total=total
            )
            product.stock -= qty
            product.save()

        resp['status'] = 'success'
        resp['sale_id'] = sale_id
    except Exception as e:
        resp['msg'] = str(e)
        print("Unexpected error:", e)

    return JsonResponse(resp)

@login_required
@never_cache
def salesList(request):
    user_groups = request.user.groups.all()
    u = request.user

    search_query = request.GET.get('q', '')
    date_str = request.GET.get('date', '')
    selected_product = request.GET.get('product', '')

    date = datetime.strptime(date_str, '%Y-%m-%d') if date_str else None

    sales = Sales.objects.all()

    if search_query:
        sales = sales.filter(
            Q(customer_name__icontains=search_query) |
            Q(customer_phone__icontains=search_query) |
            Q(code__icontains=search_query)
        )
    
    if date:
        sales = sales.filter(date_added__date=date)
    
    if selected_product:
        sales = sales.filter(salesitems__product_id=selected_product).distinct()

    sale_data = []
    for sale in sales:
        data = {}
        for field in sale._meta.get_fields(include_parents=False):
            if field.related_model is None:
                data[field.name] = getattr(sale, field.name)
        items = salesItems.objects.filter(sale_id=sale).all()
        data['items'] = items
        data['item_count'] = len(items)
        data['total_product_count'] = items.aggregate(total_qty=Sum(F('qty')))['total_qty'] or 0
        if 'tax_amount' in data:
            data['tax_amount'] = format(float(data['tax_amount']), '.2f')
        data['payment_method'] = sale.payment_method
        sale_data.append(data)

    context = {
        'page_title': 'Sales Transactions',
        'sale_data': sale_data,
        'search_query': search_query,
        'date': date_str,
        'selected_product': selected_product,
        'user_groups': user_groups,
        'u': u,
        'products': Products.objects.all()  
    }
    return render(request, 'posApp/sales.html', context)


@login_required
@never_cache
def receipt(request):
    id = request.GET.get('id')
    sales = Sales.objects.filter(id=id).first()

    if not sales:
        return JsonResponse({'status': 'failed', 'msg': 'Sale not found.'})

    transaction = {}
    for field in Sales._meta.get_fields():
        if field.related_model is None:
            transaction[field.name] = getattr(sales, field.name)

    if 'tax_amount' in transaction:
        transaction['tax_amount'] = format(float(transaction['tax_amount']), '.2f')

    sgst_percent = sales.sgst_percent
    cgst_percent = sales.cgst_percent

    ItemList = salesItems.objects.filter(sale_id=sales).all()

    tendered_amount = Decimal(transaction.get('tendered_amount', 0))
    grand_total = Decimal(transaction.get('grand_total', 0))
    change = tendered_amount - grand_total
    rounded_change = Decimal(change).quantize(Decimal('1'), rounding=ROUND_HALF_UP)

    item_details = []
    for item in ItemList:
        product = Products.objects.get(id=item.product_id.id)
        product_details = {
            'product_name': product.name,
            'mrp': product.mrp,
            'price': item.price,
            'qty': item.qty,
            'total': item.total,
        }
        item_details.append(product_details)

    context = {
        "transaction": transaction,
        "salesItems": item_details,
        "sgst_percent": sgst_percent,
        "cgst_percent": cgst_percent,
        "rounded_change": rounded_change
    }

    return render(request, 'posApp/receipt.html', context)

@login_required
@never_cache
def generate_barcode(request, code):
    try:
        barcode_class = barcode.get_barcode_class('code128')
        barcode_instance = barcode_class(code, writer=ImageWriter())
        
        buffer = BytesIO()
        barcode_instance.write(buffer)
        buffer.seek(0)
        
        image = Image.open(buffer)
        resized_image = image.resize((150,100), Image.Resampling.LANCZOS)
        
        resized_buffer = BytesIO()
        resized_image.save(resized_buffer, format='PNG')
        resized_buffer.seek(0)
        
        return HttpResponse(resized_buffer, content_type='image/png')
    except Exception as e:
        logger.error(f"Error generating barcode: {e}")
        return HttpResponseServerError("Failed to generate barcode.")
    
    
@login_required
@never_cache
def delete_sale(request):
    resp = {'status':'failed', 'msg':''}
    id = request.POST.get('id')
    try:
        delete = Sales.objects.filter(id = id).delete()
        resp['status'] = 'success'
        messages.success(request, 'Sale Record has been deleted.')
    except:
        resp['msg'] = "An error occured"
        print("Unexpected error:", sys.exc_info()[0])
    return HttpResponse(json.dumps(resp), content_type='application/json')

@csrf_exempt
def send_expiry_email(request):
    if request.method == 'POST':
        product_name = request.POST.get('product_name')
        product_status = request.POST.get('product_status')

        if product_status == 'expired':
            message = f'Hi sir, the product {product_name} is expired, please check.'
        elif product_status == 'out_of_stock':
            message = f'Hi sir, the product {product_name} is out of stock, please check.'
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid product status'}, status=400)
        
        send_mail(
            'Product Notification',
            message,
            'smtp.gmail.com',
            ['pinesphereinternship@gmail.com'],
            fail_silently=False,
        )
        
        return JsonResponse({'status': 'success', 'message': 'Email sent successfully'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

def send_stock_alert_email(product):
    subject = f'Stock Alert: {product.name}'
    message = f'The stock for {product.name} (Code: {product.code}) has fallen below the minimum level. Current stock: {product.stock}.'
    email_from = 'smtp.gmail.com'
    recipient_list = ['pinesphereinternship@gmail.com']
    send_mail(subject, message, email_from, recipient_list)

@receiver(post_save, sender=Products)
def check_stock(sender, instance, **kwargs):
    if instance.stock < instance.min_stock:
        send_stock_alert_email(instance)

@csrf_exempt
def savepos(request):
    if request.method == 'POST':
        customer_name = request.POST.get('customer_name')
        held = request.POST.get('held') == 'true'

        product_list = []
        index = 0
        while True:
            product_id = request.POST.get(f'product[{index}][id]')
            if product_id is None:
                break

            product = {
                'id': product_id,
                'name': request.POST.get(f'product[{index}][name]'),
                'mrp': request.POST.get(f'product[{index}][mrp]'),
                'price': request.POST.get(f'product[{index}][price]'),
                'code': request.POST.get(f'product[{index}][code]'),
                'expirydate': request.POST.get(f'product[{index}][expirydate]'),
                'stock': request.POST.get(f'product[{index}][stock]'),
                'quantity': request.POST.get(f'product[{index}][qty]')
            }
            product_list.append(product)
            index += 1

        for item in product_list:
            product_id = item['id']
            quantity = item['quantity']
            try:
                product = Products.objects.get(pk=product_id)
                CartItem.objects.create(
                    customer_name=customer_name,
                    product=product,
                    quantity=quantity,
                    held=held
                )
            except Products.DoesNotExist:
                return JsonResponse({'status': 'failure', 'error': f'Product with ID {product_id} does not exist'})

        return JsonResponse({'status': 'success'})

    return JsonResponse({'status': 'failure', 'error': 'Invalid request method'})

def get_held_bills(request):
    held_bills = CartItem.objects.filter(held=False).values('customer_name').distinct()
    return JsonResponse(list(held_bills), safe=False)

def getheldbilldetails(request, customer_name):
    held_items = CartItem.objects.filter(customer_name=customer_name, held=False)
    if not held_items.exists():
        print(f"No held bill found for customer: {customer_name}")
        return JsonResponse({'status': 'failure', 'error': 'No held bill found for this customer'}, status=404)
    
    product_list = []
    for item in held_items:
        product_list.append({
            'id': item.product.id,
            'name': item.product.name,
            'mrp': item.product.mrp,
            'price': item.product.price,
            'code': item.product.code,
            'expirydate': item.product.expirydate,
            'stock': item.product.stock,
            'quantity': item.quantity,
            'customer_name': customer_name
        })
    
    return JsonResponse({'status': 'success', 'product_list': product_list})

    
@login_required
@never_cache
def customerdatabase(request):
    user_groups = request.user.groups.all()
    u = request.user
    query = request.GET.get('q')
    customers = Customer.objects.all()

    if query:
        customers = customers.filter(
            Q(name__icontains=query) | 
            Q(phone_number__icontains=query) | 
            Q(area__icontains=query) | 
            Q(city__icontains=query)
        )


    context = {
        'user_groups': user_groups,
        'u': u,
        'customers': customers,
        'search_query': query,
    }

    return render(request, 'posApp/customerdatabase.html', context)

def add_customer(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone_number = request.POST.get('phone_number')
        area = request.POST.get('area')
        city = request.POST.get('city')

        if name and phone_number:
            Customer.objects.create(
                name=name,
                phone_number=phone_number,
                area=area,
                city=city
            )
            messages.success(request, 'Customer added successfully!')
        else:
            messages.error(request, 'Name and phone number are required.')

    return redirect('customerdatabase-page')

@require_http_methods(["DELETE"])
def delete_customer(request):
    customer_id = request.GET.get('id')
    if customer_id:
        try:
            customer = Customer.objects.get(pk=customer_id)
            customer.delete()
            return JsonResponse({'success': True})
        except Customer.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Customer does not exist.'})
    return JsonResponse({'success': False, 'error': 'Invalid customer ID.'})

@require_http_methods(["POST"])
def edit_customer(request):
    customer_id = request.POST.get('customer_id')
    if customer_id:
        customer = get_object_or_404(Customer, pk=customer_id)
        customer.name = request.POST.get('name')
        customer.phone_number = request.POST.get('phone_number')
        customer.area = request.POST.get('area')
        customer.city = request.POST.get('city')
        customer.save()
        return HttpResponseRedirect(reverse('customerdatabase-page'))

    return JsonResponse({'success': False, 'error': 'Invalid customer ID.'})

def get_customer_details(request):
    phone_number = request.GET.get('phone_number')
    if phone_number:
        try:
            customer = Customer.objects.get(phone_number=phone_number)
            customer_data = {
                'name': customer.name,
                'city': customer.city,
                'area': customer.area,
            }
            return JsonResponse({'status': 'success', 'data': customer_data})
        except Customer.DoesNotExist:
            return JsonResponse({'status': 'not_found'})
    return JsonResponse({'status': 'failed'})

@login_required
@never_cache
def stockreports(request):
    user_groups = request.user.groups.all()
    u=request.user
    search_query = request.GET.get('q', '')
    expirydate = request.GET.get('expirydate', '')

    filters = Q()
    
    if search_query:
        filters &= (Q(name__icontains=search_query) | 
                    Q(code__icontains=search_query) | 
                    Q(category_id__name__icontains=search_query))
    
    if expirydate:
        try:
            expirydate = datetime.strptime(expirydate, '%Y-%m-%d').date()
            filters &= Q(expirydate__lte=expirydate)
        except ValueError:
            
            pass

    product_list = Products.objects.filter(filters)

    context = {
        'page_title': 'Product List',
        'products': product_list,
        'search_query': search_query,
        'expiry_date': expirydate,
        'user_groups': user_groups,
        'u':u,
    }
    return render(request, 'posApp/stockreports.html', context)

def fetch_billed_products(request):
    if request.method == 'POST':
        import json
        data = json.loads(request.body)
        sale_code = data.get('sale_id')

        if not sale_code:
            return JsonResponse({'status': 'error', 'message': 'Sale ID is required'}, status=400)

        sales_instance = get_object_or_404(Sales, code=sale_code)
        
        sales_items = salesItems.objects.filter(sale_id=sales_instance)

        sales_items_data = []
        for item in sales_items:
            sales_items_data.append({
                'product_name': item.product_id.name,
                'product_id': item.product_id.id,
                'mrp': item.mrp,
                'price': item.price,
                'qty': item.qty,
                'total': item.total,
            })

        response_data = {
            'status': 'success',
            'sale': {
                'code': sales_instance.code,
                'sub_total': sales_instance.sub_total,
                'grand_total': sales_instance.grand_total,
                'tax_amount': sales_instance.tax_amount,
                'tendered_amount': sales_instance.tendered_amount,
                'amount_change': sales_instance.amount_change,
                'customer_name': sales_instance.customer_name,
                'customer_phone': sales_instance.customer_phone,
                'date_added': sales_instance.date_added,
                'payment_method': sales_instance.get_payment_method_display(),
                'sgst_percent': sales_instance.sgst_percent,
                'cgst_percent': sales_instance.cgst_percent,
            },
            'sales_items': sales_items_data
        }

        return JsonResponse(response_data, status=200)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)    

@login_required
@never_cache
def productreturn(request):
    user_groups = request.user.groups.all()
    u=request.user

    context = {
        'user_groups': user_groups,
        'u':u,
    }

    return render(request, 'posApp/return.html',context)

    


@csrf_exempt
def update_sales_and_salesitems(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            sale_code = data.get('sale_code')
            returned_items = data.get('returned_items')

            if not sale_code or not returned_items:
                return JsonResponse({'status': 'error', 'message': 'Sale code and returned items are required'}, status=400)

            sales_instance = get_object_or_404(Sales, code=sale_code)

            updated_items = []
            for item in returned_items:
                sales_item = salesItems.objects.get(sale_id=sales_instance, product_id_id=item['product_id'])
                product = get_object_or_404(Products, id=item['product_id'])

                returned_qty = item['returned_qty']
                
                # Create a new record in the ReturnedItems table
                returned_item = ReturnedItems(
                    sale_id=sales_instance,
                    product_id=product,
                    price=sales_item.price,
                    qty=returned_qty
                )
                returned_item.save()

                # Update the product stock
                product.stock += returned_qty
                product.save()

                updated_items.append({
                    'product_id': product.id,
                    'qty': returned_qty,
                    'total': returned_item.total
                })

            total_amount = sum(item.total for item in salesItems.objects.filter(sale_id=sales_instance))
            total_returns = sum(item.total for item in ReturnedItems.objects.filter(sale_id=sales_instance))
            total_tax = (total_amount - total_returns) * (float(sales_instance.sgst_percent) + float(sales_instance.cgst_percent)) / 100
            grand_total = (total_amount - total_returns) + total_tax

            sales_instance.sub_total = total_amount - total_returns
            sales_instance.tax_amount = total_tax
            sales_instance.grand_total = grand_total
            sales_instance.save()

            return JsonResponse({
                'status': 'success',
                'updated_items': updated_items
            }, status=200)

        except salesItems.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Sales item not found'}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)


@csrf_exempt
def remove_held_bill(request, customer_name):
    if request.method == 'DELETE':
        try:
            # Decode the customer_name if necessary
            customer_name = customer_name.replace('%20', ' ')
            
            held_bills = CartItem.objects.filter(customer_name=customer_name)
            
            if not held_bills.exists():
                logger.error(f'Held bill not found for customer: {customer_name}')
                return JsonResponse({'status': 'error', 'message': 'Held bill not found'}, status=404)

            held_bills.delete()
            return JsonResponse({'status': 'success', 'message': 'Held bill(s) removed successfully'}, status=200)
        
        except Exception as e:
            logger.exception(f'Error removing held bill for customer: {customer_name}')
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

@login_required
@never_cache
def ReturnReceipt(request):
    id = request.GET.get('id')
    sales = Sales.objects.filter(code=id).first()

    if not sales:
        return JsonResponse({'status': 'failed', 'msg': 'Sale not found.'})

    transaction = {}
    for field in Sales._meta.get_fields():
        if field.related_model is None:
            transaction[field.name] = getattr(sales, field.name)

    if 'tax_amount' in transaction:
        transaction['tax_amount'] = format(float(transaction['tax_amount']), '.2f')

    sgst_percent = sales.sgst_percent
    cgst_percent = sales.cgst_percent

    ItemList = salesItems.objects.filter(sale_id=sales).all()
    ReturnedItemList = ReturnedItems.objects.filter(sale_id=sales).all()

    tendered_amount = Decimal(transaction.get('tendered_amount', 0))
    grand_total = Decimal(transaction.get('grand_total', 0))
    change = tendered_amount - grand_total
    rounded_change = Decimal(change).quantize(Decimal('1'), rounding=ROUND_HALF_UP)

    item_details = []
    for item in ItemList:
        product = Products.objects.get(id=item.product_id.id)
        product_details = {
            'product_name': product.name,
            'mrp': product.mrp,
            'price': item.price,
            'qty': item.qty,
            'total': item.total,
        }
        item_details.append(product_details)

    returned_item_details = []
    for returned_item in ReturnedItemList:
        product = Products.objects.get(id=returned_item.product_id.id)
        returned_product_details = {
            'product_name': product.name,
            'price': returned_item.price,
            'qty': returned_item.qty,
            'total': returned_item.total,
            'date_returned': returned_item.date_returned
        }
        returned_item_details.append(returned_product_details)

    context = {
        "transaction": transaction,
        "salesItems": item_details,
        "returnedItems": returned_item_details,
        "sgst_percent": sgst_percent,
        "cgst_percent": cgst_percent,
        "rounded_change": rounded_change
    }

    return render(request, 'posApp/returnReceipt.html', context)

def get_product_by_barcode(request):
    barcode = request.GET.get('barcode')
    print("Received barcode:", barcode)  
    try:
        product = Products.objects.get(code=barcode)
        
        print("Found product:", product)
        return JsonResponse({'status': 'success', 'product_id': product.pk})
    except Products.DoesNotExist:
        print("Product with barcode not found") 
        return JsonResponse({'status': 'error', 'message': 'Product not found'})
