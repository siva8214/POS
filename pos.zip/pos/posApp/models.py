from datetime import datetime
from unicodedata import category
from django.db import models
from django.utils import timezone
from barcode import Code128
from barcode.writer import ImageWriter
from io import BytesIO
from django.core.files import File

# Create your models here.

MINIMUM_STOCK_LEVEL = 5

class Category(models.Model):
    name = models.TextField() 
    date_added = models.DateTimeField(default=timezone.now) 
    date_updated = models.DateTimeField(auto_now=True) 

    def __str__(self):
        return self.name

class Products(models.Model):
    code = models.CharField(max_length=100)
    category_id = models.ForeignKey(Category, on_delete=models.CASCADE)
    name = models.TextField()
    qty = models.CharField(max_length=20)
    mrp = models.FloatField(default=0)
    price = models.FloatField(default=0)
    expirydate = models.DateField(null=True, blank=True) 
    stock = models.IntegerField(default=0)
    min_stock = models.IntegerField(default=MINIMUM_STOCK_LEVEL)
    date_added = models.DateTimeField(default=timezone.now) 
    date_updated = models.DateTimeField(auto_now=True)
    barcode = models.CharField(max_length=255, blank=True, null=True)


    

    def __str__(self):
        return self.code + " - " + self.name

class Sales(models.Model):

    code = models.CharField(max_length=100, unique=True, blank=True, null=True)
    sub_total = models.FloatField(default=0)
    grand_total = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    tax = models.FloatField(default=0)
    tendered_amount = models.FloatField(default=0)
    amount_change = models.FloatField(default=0)
    customer_name = models.CharField(max_length=100)  
    customer_phone = models.CharField(max_length=20)
    date_added = models.DateTimeField(default=timezone.now) 
    date_updated = models.DateTimeField(auto_now=True)
    sgst_percent = models.DecimalField(max_digits=5, decimal_places=2)  # SGST Percentage
    cgst_percent = models.DecimalField(max_digits=5, decimal_places=2)
    
    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('card', 'Card'),
        ('gpay', 'GPay'),
    ]
    payment_method = models.CharField(max_length=10, choices=PAYMENT_METHOD_CHOICES)

    def __str__(self):
        return self.code
    
    def save(self, *args, **kwargs):
        if not self.code:
            current_year = datetime.now().year
            last_sales = Sales.objects.filter(code__startswith=f"INV/{current_year}/").order_by('id').last()
            if last_sales:
                last_code = int(last_sales.code.split('/')[-1])
                self.code = f"INV/{current_year}/{last_code + 1:05d}"
            else:
                self.code = f"INV/{current_year}/00001"
        super().save(*args, **kwargs)
    
    
    
class salesItems(models.Model):
    sale_id = models.ForeignKey(Sales,on_delete=models.CASCADE)
    product_id = models.ForeignKey(Products,on_delete=models.CASCADE)
    mrp = models.FloatField(default=0)
    price = models.FloatField(default=0)
    qty = models.DecimalField(max_digits=10, decimal_places=2)
    total = models.FloatField(default=0)

class CartItem(models.Model):
    customer_name = models.CharField(max_length=255)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0)  # Add quantity field
    held = models.BooleanField(default=False)

    def __str__(self):
         return f'{self.customer_name} - {self.product.name} - {self.quantity}'
    
class Customer(models.Model):
    name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=20)
    city = models.CharField(max_length=255, blank=True, null=True)
    area = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name
    

class ReturnedItems(models.Model):
    sale_id = models.ForeignKey(Sales, on_delete=models.CASCADE)
    product_id = models.ForeignKey(Products, on_delete=models.CASCADE)
    price = models.FloatField(default=0)
    qty = models.DecimalField(max_digits=10, decimal_places=2)
    total = models.FloatField(default=0)
    date_returned = models.DateTimeField(default=timezone.now)
    
    def save(self, *args, **kwargs):
        self.total = float(self.price) * float(self.qty)
        super().save(*args, **kwargs)