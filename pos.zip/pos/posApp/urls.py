from . import views
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path
from django.views.generic.base import RedirectView

urlpatterns = [
    path('redirect-admin', RedirectView.as_view(url="/admin"),name="redirect-admin"),
    path('', views.home, name="home-page"),
    path('login', auth_views.LoginView.as_view(template_name = 'posApp/login.html',redirect_authenticated_user=True), name="login"),
    path('userlogin', views.login_user, name="login-user"),
    path('logout', views.logoutuser, name="logout"),
    path('category', views.category, name="category-page"),
    path('manage_category', views.manage_category, name="manage_category-page"),
    path('save_category', views.save_category, name="save-category-page"),
    path('delete_category', views.delete_category, name="delete-category"),
    path('products', views.products, name="product-page"),
    path('manage_products', views.manage_products, name="manage_products-page"),
    path('test', views.test, name="test-page"),
    path('save_product', views.save_product, name="save-product-page"),
    path('delete_product', views.delete_product, name="delete-product"),
    path('pos', views.pos, name="pos-page"),
    path('checkout-modal', views.checkout_modal, name="checkout-modal"),
    path('save-pos', views.save_pos, name="save-pos"),
    path('sales', views.salesList, name="sales-page"),
    path('receipt', views.receipt, name="receipt-modal"),
    path('returnreceipt', views.ReturnReceipt, name="return-receipt-modal"),
    path('delete_sale', views.delete_sale, name="delete-sale"),
    path('generate_barcode/<path:code>/', views.generate_barcode, name='generate_barcode'),
    path('get_product_by_barcode/', views.get_product_by_barcode, name='get_product_by_barcode'),
    path('send-expiry-email/', views.send_expiry_email, name='send-expiry-email'),
    path('get_held_bills/', views.get_held_bills, name='get_held_bills'),
    path('savepos', views.savepos, name="savepos"),
    path('getheldbilldetails/<str:customer_name>/', views.getheldbilldetails, name='getheldbilldetails'),
    path('customerdatabase/', views.customerdatabase, name='customerdatabase-page'),
    path('add_customer/', views.add_customer, name='add_customer'),
    path('delete_customer/', views.delete_customer, name='delete_customer'),
    path('edit_customer/', views.edit_customer, name='edit_customer'),
    path('stockreports/', views.stockreports, name='stockreports-page'),
    path('productreturn/', views.productreturn, name='return-page'),
    path('fetch_billed_products', views.fetch_billed_products, name='fetch_billed_products'),
    path('update_sales_and_salesitems/', views.update_sales_and_salesitems, name='update_sales_and_salesitems'),
    path('removeheldbill/<str:customer_name>/', views.remove_held_bill, name='remove_held_bill'),
    path('get_customer_details/', views.get_customer_details, name='get_customer_details'),
   
    
]